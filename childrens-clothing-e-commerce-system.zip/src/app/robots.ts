import type { MetadataRoute } from "next";

export default function robots(): MetadataRoute.Robots {
  return {
    rules: [
      { userAgent: "*", allow: ["/", "/shop", "/product"], disallow: ["/admin", "/pos", "/api"] },
    ],
  };
}
